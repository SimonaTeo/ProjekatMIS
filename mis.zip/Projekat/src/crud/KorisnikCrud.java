package crud;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Korisnik;

public class KorisnikCrud {
	public Korisnik prijava(String kIme, String lozinka) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Korisnici.txt"));
		String linija;
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			if(kIme.equals(delovi[2]) && lozinka.equals(delovi[3])) {
				Korisnik k = new Korisnik(delovi[0], delovi[1], delovi[2], delovi[3], delovi[4], delovi[5]);
				br.close();
				return k;
			}

		}
		br.close();
		return null;
	}
	
	public Korisnik registracija(String ime, String prezime, String kIme, String lozinka, String adresa, String brTel) throws IOException {
		FileWriter fw = null; 
		BufferedWriter bw = null; 
		PrintWriter pw = null;
		
		try { 
			fw = new FileWriter("Korisnici.txt", true); 
			bw = new BufferedWriter(fw); 
			pw = new PrintWriter(bw); 
			pw.println(ime + ";" + prezime + ";" + kIme + ";" + lozinka + ";" + adresa + ";" + brTel+ ";");
			pw.flush(); 
			} finally { 
				try { 
					pw.close(); 
					bw.close(); 
					fw.close();
					Korisnik k = new Korisnik(ime, prezime, kIme, lozinka, adresa, brTel);
					return k;
				} catch (IOException io) {// can't do anything } } }
			}
		}
		return null;
	}
	
	public void azuriraj(Korisnik k, String nAdresa, String nBroj, String nLozinka) throws IOException {
		
//		prijava(k.getKorIme(), k.getLozinka());
		
	      String filePath = "Korisnici.txt";
	      //Instantiating the Scanner class to read the file
	      Scanner sc = new Scanner(new File(filePath));
	      //instantiating the StringBuffer class
	      StringBuffer buffer = new StringBuffer();
	      //Reading lines of the file and appending them to StringBuffer
	      while (sc.hasNextLine()) {
	         buffer.append(sc.nextLine()+System.lineSeparator());
	      }
	      String fileContents = buffer.toString();
	      System.out.println("Contents of the file: "+fileContents);
	      //closing the Scanner object
	      sc.close();
	      String oldLine = k.getIme() + ";" + k.getPrezime() + ";" + k.getKorIme() + ";" + k.getLozinka() + ";" + k.getAdresa() + ";" + k.getBrTel()+ ";";
	      String newLine = k.getIme() + ";" + k.getPrezime() + ";" + k.getKorIme() + ";" + nLozinka + ";" + nAdresa + ";" + nBroj + ";";
	      //Replacing the old line with new line
	      fileContents = fileContents.replaceAll(oldLine, newLine);
	      //instantiating the FileWriter class
	      FileWriter writer = new FileWriter(filePath);
	      System.out.println("");
	      System.out.println("new data: "+fileContents);
	      writer.append(fileContents);
	      writer.flush();
	      writer.close();
	}
	
	public List<Korisnik> korisnici() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Korisnici.txt"));
		String linija;
		List<Korisnik> kk = new ArrayList<Korisnik>();
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			Korisnik k = new Korisnik(delovi[0], delovi[1], delovi[2], delovi[3], delovi[4], delovi[5]);
			kk.add(k);

		}
		br.close();
		return kk;
	}
	
	public boolean obrisi(Korisnik k) {
		return false;
	}
	
}
