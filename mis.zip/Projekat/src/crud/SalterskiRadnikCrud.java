package crud;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import model.Korisnik;
import model.SalterskiRadnik;

public class SalterskiRadnikCrud {
	public SalterskiRadnik prijava(String ime, String lozinka) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Radnici.txt"));
		String linija;
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			if(ime.equals(delovi[0]) && lozinka.equals(delovi[5])) {
				SalterskiRadnik sr = new SalterskiRadnik(delovi[0], delovi[1], delovi[2], delovi[3], delovi[4], delovi[5]);
				br.close();
				return sr;
			}

		}
		br.close();
		return null;
	}
	
	public SalterskiRadnik dodaj(String ime, String prezime, String email, String id, String pozicija, String lozinka) throws IOException {
		FileWriter fw = null; 
		BufferedWriter bw = null; 
		PrintWriter pw = null;
		
		try { 
			fw = new FileWriter("Radnici.txt", true); 
			bw = new BufferedWriter(fw); 
			pw = new PrintWriter(bw); 
			pw.println(ime + ";" + prezime + ";" + email + ";" + id + ";" + pozicija + ";" + lozinka + ";");
			pw.flush(); 
			} finally { 
				try { 
					pw.close(); 
					bw.close(); 
					fw.close();
					SalterskiRadnik sr = new SalterskiRadnik(ime, prezime, email, id, pozicija, lozinka);
					return sr;
				} catch (IOException io) {// can't do anything } } }
			}
		}
		return null;
	}

	public List<SalterskiRadnik> radnici() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Radnici.txt"));
		String linija;
		List<SalterskiRadnik> srr = new ArrayList<SalterskiRadnik>();
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			SalterskiRadnik sr = new SalterskiRadnik(delovi[0], delovi[1], delovi[2], delovi[3], delovi[4], delovi[5]);
			srr.add(sr);

		}
		br.close();
		return srr;
	}
	public boolean obrisi(SalterskiRadnik sr) {
		return false;
	}
}
