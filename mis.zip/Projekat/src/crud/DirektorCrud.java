package crud;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import model.Direktor;


public class DirektorCrud {
	public Direktor prijava(String kIme, String lozinka) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Direktori.txt"));
		String linija;
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			if(kIme.equals(delovi[0]) && lozinka.equals(delovi[3])) {
				Direktor d = new Direktor(delovi[0], delovi[1], delovi[2], delovi[3]);
				br.close();
				return d;
			}

		}
		br.close();
		return null;
	}

}
