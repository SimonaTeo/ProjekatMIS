package crud;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import model.SalterskiRadnik;
import model.Sef;

public class SefCrud {
	public Sef prijava(String kIme, String lozinka) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Direktori.txt"));
		String linija;
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			if(kIme.equals(delovi[0]) && lozinka.equals(delovi[2])) {
				Sef s = new Sef(delovi[0], delovi[1], delovi[2]);
				br.close();
				return s;
			}

		}
		br.close();
		return null;
	}

	public Sef dodajSefa(String ime, String prezime, String lozinka) throws IOException {
		FileWriter fw = null; 
		BufferedWriter bw = null; 
		PrintWriter pw = null;
		
		try { 
			fw = new FileWriter("Sefovi.txt", true); 
			bw = new BufferedWriter(fw); 
			pw = new PrintWriter(bw); 
			pw.println(ime + ";" + prezime + ";" + lozinka + ";");
			pw.flush(); 
		} finally { 
			try { 
				pw.close(); 
				bw.close(); 
				fw.close();
				Sef s = new Sef(ime, prezime, lozinka);
				return s;
			} catch (IOException io) {
			}
		}
		return null;
	}
	
	public List<Sef> sefovi() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("Sefovi.txt"));
		String linija;
		List<Sef> ss = new ArrayList<Sef>();
		while((linija = br.readLine()) != null) {
			String[] delovi = linija.split(";");
			Sef s = new Sef(delovi[0], delovi[1], delovi[2]);
			ss.add(s);

		}
		br.close();
		return ss;
	}
	
	public boolean obrisi(Sef s) {
		return false;
	}
	
}
