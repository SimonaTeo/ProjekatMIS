package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.KorisnikCrud;
import model.Korisnik;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Prijava extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfKIme;
	private JTextField tfLozinka;
	KorisnikCrud crud = new KorisnikCrud();
	static Korisnik k;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Prijava dialog = new Prijava();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	
	public static Korisnik getKorisnik() {
		return k;
	}
	
	public static void setKorisnik(Korisnik k1) {
		k = k1;
	}
	
	public Prijava() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblKIme = new JLabel("Korisnicko ime");
		lblKIme.setBounds(27, 42, 91, 14);
		contentPanel.add(lblKIme);
		
		tfKIme = new JTextField();
		tfKIme.setBackground(new Color(255, 204, 102));
		tfKIme.setBounds(128, 39, 296, 20);
		contentPanel.add(tfKIme);
		tfKIme.setColumns(10);
		
		JLabel lblLozinka = new JLabel("Lozinka");
		lblLozinka.setBounds(27, 113, 46, 14);
		contentPanel.add(lblLozinka);
		
		tfLozinka = new JTextField();
		tfLozinka.setBackground(new Color(255, 204, 102));
		tfLozinka.setBounds(128, 110, 296, 20);
		contentPanel.add(tfLozinka);
		tfLozinka.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 204, 204));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Prijavi se");
				okButton.setBackground(new Color(0, 204, 204));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String kIme = tfKIme.getText();
						String lozinka = tfLozinka.getText();
						try {
							Korisnik k = null;
							if((k = crud.prijava(kIme, lozinka)) != null) {
								JOptionPane.showMessageDialog(Prijava.this, "Uspesna prijava.");
								setVisible(false);
								setKorisnik(k);
								Pocetna pp = new Pocetna();
								pp.setVisible(true);
							}else {
								JOptionPane.showMessageDialog(Prijava.this, "Netacni podaci.");
							}
						} catch (HeadlessException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Odustani");
				cancelButton.setBackground(new Color(0, 204, 204));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
