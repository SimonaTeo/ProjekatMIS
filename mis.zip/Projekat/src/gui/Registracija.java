package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.KorisnikCrud;
import model.Korisnik;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Registracija extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblIme;
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfBrojTel;
	private JTextField tfAdresa;
	private JTextField tfKIme;
	private JTextField tfLozinka;
	KorisnikCrud crud = new KorisnikCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Registracija dialog = new Registracija();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Registracija() {
		setTitle("Registracija");
		setBounds(100, 100, 450, 365);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			lblIme = new JLabel("Ime");
			lblIme.setBounds(25, 35, 46, 14);
			contentPanel.add(lblIme);
		}
		{
			tfIme = new JTextField();
			tfIme.setBackground(new Color(255, 204, 102));
			tfIme.setBounds(115, 32, 309, 20);
			contentPanel.add(tfIme);
			tfIme.setColumns(10);
		}
		{
			JLabel lblPrezime = new JLabel("Prezime");
			lblPrezime.setBounds(25, 80, 46, 14);
			contentPanel.add(lblPrezime);
		}
		{
			tfPrezime = new JTextField();
			tfPrezime.setBackground(new Color(255, 204, 102));
			tfPrezime.setBounds(115, 77, 309, 20);
			contentPanel.add(tfPrezime);
			tfPrezime.setColumns(10);
		}
		{
			JLabel lblBrTel = new JLabel("Broj telefona");
			lblBrTel.setBounds(25, 125, 80, 14);
			contentPanel.add(lblBrTel);
		}
		{
			tfBrojTel = new JTextField();
			tfBrojTel.setBackground(new Color(255, 204, 102));
			tfBrojTel.setBounds(115, 122, 309, 20);
			contentPanel.add(tfBrojTel);
			tfBrojTel.setColumns(10);
		}
		{
			JLabel lblAdresa = new JLabel("Adresa");
			lblAdresa.setBounds(25, 170, 46, 14);
			contentPanel.add(lblAdresa);
		}
		{
			tfAdresa = new JTextField();
			tfAdresa.setBackground(new Color(255, 204, 102));
			tfAdresa.setBounds(115, 167, 309, 20);
			contentPanel.add(tfAdresa);
			tfAdresa.setColumns(10);
		}
		{
			JLabel lblKIme = new JLabel("Korisnicko ime");
			lblKIme.setBounds(25, 216, 80, 14);
			contentPanel.add(lblKIme);
		}
		{
			tfKIme = new JTextField();
			tfKIme.setBackground(new Color(255, 204, 102));
			tfKIme.setBounds(115, 213, 309, 20);
			contentPanel.add(tfKIme);
			tfKIme.setColumns(10);
		}
		{
			JLabel lblLozinka = new JLabel("Lozinka");
			lblLozinka.setBounds(25, 268, 46, 14);
			contentPanel.add(lblLozinka);
		}
		{
			tfLozinka = new JTextField();
			tfLozinka.setBackground(new Color(255, 204, 102));
			tfLozinka.setBounds(115, 265, 309, 20);
			contentPanel.add(tfLozinka);
			tfLozinka.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 204, 204));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Prijavi se");
				okButton.setBackground(new Color(0, 204, 204));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String ime = tfIme.getText();
						String prezime = tfPrezime.getText();
						String brojTel = tfBrojTel.getText();
						String adresa = tfAdresa.getText();
						String kIme =  tfKIme.getText();
						String lozinka = tfLozinka.getText();
						Korisnik k = new Korisnik(ime, prezime, kIme, lozinka, brojTel, adresa);
						try {
							crud.registracija(ime, prezime, kIme, lozinka, adresa, brojTel);
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						setVisible(false);
						Pocetna p = new Pocetna();
						p.setVisible(true);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(0, 204, 204));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
