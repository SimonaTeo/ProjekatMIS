package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class GlavniProzor {

	private JFrame frmPrijava;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GlavniProzor window = new GlavniProzor();
					window.frmPrijava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GlavniProzor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPrijava = new JFrame();
		frmPrijava.setBackground(new Color(0, 204, 204));
		frmPrijava.getContentPane().setForeground(new Color(0, 0, 0));
		frmPrijava.getContentPane().setBackground(new Color(255, 255, 153));
		frmPrijava.setTitle("Prijava korisnika");
		frmPrijava.setBounds(100, 100, 450, 300);
		frmPrijava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPrijava.getContentPane().setLayout(null);
		
		JButton btnIma = new JButton("Imam nalog");
		btnIma.setBackground(new Color(0, 204, 204));
		btnIma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Prijava p = new Prijava();
				p.setVisible(true);
			}
		});
		btnIma.setBounds(52, 110, 114, 34);
		frmPrijava.getContentPane().add(btnIma);
		
		JButton btnNema = new JButton("Nemam nalog");
		btnNema.setBackground(new Color(0, 204, 204));
		btnNema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Registracija r = new Registracija();
				r.setVisible(true);
			}
		});
		btnNema.setBounds(238, 110, 114, 34);
		frmPrijava.getContentPane().add(btnNema);
	}
}
