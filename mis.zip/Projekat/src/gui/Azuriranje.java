package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.KorisnikCrud;
import model.Korisnik;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Azuriranje extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfNAdresa;
	private JTextField tfNBrTel;
	private JTextField tfNLoznika;
	KorisnikCrud crud = new KorisnikCrud();
	static Korisnik k;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			k = Pocetna.getKorisnik();
			Azuriranje dialog = new Azuriranje();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	
	public static Korisnik getKorisnik() {
		return k;
	}	
	
	public Azuriranje() {
		setBackground(new Color(0, 204, 204));
		setTitle("Azuriranje profila");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNAdresa = new JLabel("Adresa");
			lblNAdresa.setBounds(26, 32, 46, 14);
			contentPanel.add(lblNAdresa);
		}
		{
			tfNAdresa = new JTextField();
			tfNAdresa.setBackground(new Color(255, 204, 102));
			tfNAdresa.setBounds(114, 29, 310, 20);
			contentPanel.add(tfNAdresa);
			tfNAdresa.setColumns(10);
		}
		{
			JLabel lblNBrTel = new JLabel("Broj telefona");
			lblNBrTel.setBounds(26, 96, 78, 14);
			contentPanel.add(lblNBrTel);
		}
		{
			tfNBrTel = new JTextField();
			tfNBrTel.setBackground(new Color(255, 204, 102));
			tfNBrTel.setBounds(114, 93, 310, 20);
			contentPanel.add(tfNBrTel);
			tfNBrTel.setColumns(10);
		}
		{
			JLabel lblNLozinka = new JLabel("Loznika");
			lblNLozinka.setBounds(26, 161, 78, 14);
			contentPanel.add(lblNLozinka);
		}
		{
			tfNLoznika = new JTextField();
			tfNLoznika.setBackground(new Color(255, 204, 102));
			tfNLoznika.setBounds(114, 158, 310, 20);
			contentPanel.add(tfNLoznika);
			tfNLoznika.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 204, 204));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Azuriraj");
				okButton.setForeground(new Color(0, 0, 0));
				okButton.setBackground(new Color(0, 204, 204));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String adresa = tfNAdresa.getText();
						String br = tfNBrTel.getText();
						String lozinka = tfNLoznika.getText();
						k = getKorisnik();
						try {
							crud.azuriraj(k, adresa, br, lozinka);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(0, 204, 204));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
