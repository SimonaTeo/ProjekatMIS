package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Color;

public class Usluge extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Usluge dialog = new Usluge();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Usluge() {
		setTitle("Prikaz svih usluga");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(new Color(255, 204, 102));
		comboBox.setBounds(10, 28, 414, 22);
		contentPanel.add(comboBox);
		String[] usluge = {"Novcane usluge", "Usluge slanja i primanja posiljaka", "Pracenje posiljaka", "Usluge stampe", "Usluge placanja", "Dopunske usluge i usluge po sluzbenoj duznosti", "Ostale usluge"};
		for(String u : usluge) {
			comboBox.addItem(u);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 204, 204));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Izaberi");
				okButton.setBackground(new Color(0, 204, 204));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String usluga = (String)comboBox.getSelectedItem();
						if(usluga.equals(usluge[0])) {
							JComboBox comboBox_1 = new JComboBox();
							comboBox_1.setBounds(10, 97, 414, 22);
							contentPanel.add(comboBox_1);
							String[] usluge = {"Transfer novca", "Menjanje novca"};
							for(String u : usluge) {
								comboBox_1.addItem(u);
							}
						}
						if(usluga.equals(usluge[1])) {
							JComboBox comboBox_1 = new JComboBox();
							comboBox_1.setBounds(10, 97, 414, 22);
							contentPanel.add(comboBox_1);
							String[] usluge = {"Slanje pismenih posiljaka", "Slanje expres posiljaka", "Slanje paketa", "Slanje telegrama", "Prijem oglasnih poruka"};
							for(String u : usluge) {
								comboBox_1.addItem(u);
							}
						}
						if(usluga.equals(usluge[2])) {

						}
						if(usluga.equals(usluge[3])) {
							JComboBox comboBox_1 = new JComboBox();
							comboBox_1.setBounds(10, 97, 414, 22);
							contentPanel.add(comboBox_1);
							String[] usluge = {"Digitalni zeleni sertifikat"};
							for(String u : usluge) {
								comboBox_1.addItem(u);
							}
						}
						if(usluga.equals(usluge[4])) {
							JComboBox comboBox_1 = new JComboBox();
							comboBox_1.setBounds(10, 97, 414, 22);
							contentPanel.add(comboBox_1);
							String[] usluge = {"Placanje racuna", "Uplata na karticu", "E-dopuna"};
							for(String u : usluge) {
								comboBox_1.addItem(u);
							}
						}
						if(usluga.equals(usluge[5])) {

						}
						if(usluga.equals(usluge[6])) {
							JComboBox comboBox_1 = new JComboBox();
							comboBox_1.setBounds(10, 97, 414, 22);
							contentPanel.add(comboBox_1);
							String[] usluge = {"Digitalni zeleni sertifikat", "Izdavanje nepokretnosti", "Osiguranje"};
							for(String u : usluge) {
								comboBox_1.addItem(u);
							}
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(0, 204, 204));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
