package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Korisnik;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import gui.Prijava;
import java.awt.Color;

public class Pocetna extends JDialog {

	private final JPanel contentPanel = new JPanel();
	static Korisnik k;

	public static void setKorisnik(Korisnik k1) {
		k = k1;
	}
	
	public static Korisnik getKorisnik() {
		return k;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			k = Prijava.getKorisnik();
			Pocetna dialog = new Pocetna();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */

	
	public Pocetna() {
		setBackground(new Color(0, 204, 204));
		setTitle("Meni");
		setBounds(100, 100, 470, 330);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnAzuriranje = new JButton("Azuriranje profila");
			btnAzuriranje.setBackground(new Color(0, 204, 204));
			btnAzuriranje.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					Azuriranje aa = new Azuriranje();
					aa.setVisible(true);
				}
			});
			btnAzuriranje.setBounds(32, 39, 147, 37);
			contentPanel.add(btnAzuriranje);
		}
		{
			JButton btnPPosiljaka = new JButton("Prikaz posiljki");
			btnPPosiljaka.setBackground(new Color(0, 204, 204));
			btnPPosiljaka.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Posiljke p = new Posiljke();
					p.setVisible(true);
				}
			});
			btnPPosiljaka.setBounds(32, 103, 147, 37);
			contentPanel.add(btnPPosiljaka);
		}
		{
			JButton btnPUsluga = new JButton("Prikaz usluga");
			btnPUsluga.setBackground(new Color(0, 204, 204));
			btnPUsluga.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Usluge u = new Usluge();
					u.setVisible(true);
				}
			});
			btnPUsluga.setBounds(32, 166, 147, 37);
			contentPanel.add(btnPUsluga);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 204, 204));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setBackground(new Color(0, 204, 204));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setBackground(new Color(0, 204, 204));
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
