package guiD;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.SalterskiRadnikCrud;
import model.Korisnik;
import model.SalterskiRadnik;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Color;

public class BrisanjeRadnika extends JDialog {

	private final JPanel contentPanel = new JPanel();
	JComboBox comboBox;
	SalterskiRadnikCrud src= new SalterskiRadnikCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BrisanjeRadnika dialog = new BrisanjeRadnika();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws IOException 
	 */
	public BrisanjeRadnika() throws IOException {
		setTitle("Brisanje radnika");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 204, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			comboBox = new JComboBox();
			comboBox.setBackground(new Color(255, 255, 153));
			comboBox.setBounds(10, 38, 414, 22);
			contentPanel.add(comboBox);
			List<SalterskiRadnik> radnici = src.radnici();
			for(SalterskiRadnik r : radnici) {
				comboBox.addItem(r);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(255, 255, 153));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Obrisi");
				okButton.setBackground(new Color(255, 255, 153));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SalterskiRadnik radnik = (SalterskiRadnik)comboBox.getSelectedItem();
						if(!src.obrisi(radnik)) {
							JOptionPane.showMessageDialog(null, "Brisanje nije uspelo.");
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(255, 255, 153));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
