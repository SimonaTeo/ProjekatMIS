package guiD;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.IOException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.KorisnikCrud;
import model.Korisnik;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class BrisanjeKorisnika extends JDialog {

	private final JPanel contentPanel = new JPanel();
	KorisnikCrud kc = new KorisnikCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BrisanjeKorisnika dialog = new BrisanjeKorisnika();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 * @throws IOException 
	 */
	public BrisanjeKorisnika() throws IOException {
		setTitle("Brisanje korisnika");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 204, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBackground(new Color(255, 255, 153));
		comboBox.setBounds(10, 23, 414, 22);
		List<Korisnik> korisnici = kc.korisnici();
		for(Korisnik k : korisnici) {
			comboBox.addItem(k);
		}
		contentPanel.add(comboBox);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(255, 255, 153));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Obrisi");
				okButton.setBackground(new Color(255, 255, 153));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Korisnik korisnik = (Korisnik)comboBox.getSelectedItem();
						if(!kc.obrisi(korisnik)) {
							JOptionPane.showMessageDialog(null, "Brisanje nije uspelo.");
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(255, 255, 153));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
