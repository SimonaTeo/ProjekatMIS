package guiD;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Meni extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Meni dialog = new Meni();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Meni() {
		setTitle("Meni");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 204, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton btnDodajSefa = new JButton("Dodaj sefa");
			btnDodajSefa.setBackground(new Color(255, 255, 153));
			btnDodajSefa.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DodavanjeSefa ds = new DodavanjeSefa();
					ds.setVisible(true);
				}
			});
			btnDodajSefa.setBounds(45, 59, 135, 23);
			contentPanel.add(btnDodajSefa);
		}
		{
			JButton btnBrisanjeSeva = new JButton("Obrisi sefa");
			btnBrisanjeSeva.setBackground(new Color(255, 255, 153));
			btnBrisanjeSeva.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					BrisanjeSefa bs;
					try {
						bs = new BrisanjeSefa();
						bs.setVisible(true);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			});
			btnBrisanjeSeva.setBounds(223, 59, 135, 23);
			contentPanel.add(btnBrisanjeSeva);
		}
		{
			JButton btnDodajKorisnika = new JButton("Dodaj korisnika");
			btnDodajKorisnika.setBackground(new Color(255, 255, 153));
			btnDodajKorisnika.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DodavanjeKorisnika dk = new DodavanjeKorisnika();
					dk.setVisible(true);
				}
			});
			btnDodajKorisnika.setBounds(45, 119, 135, 23);
			contentPanel.add(btnDodajKorisnika);
		}
		{
			JButton btnObrisiKorisnika = new JButton("Obrisi korisnika");
			btnObrisiKorisnika.setBackground(new Color(255, 255, 153));
			btnObrisiKorisnika.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					BrisanjeKorisnika bk;
					try {
						bk = new BrisanjeKorisnika();
						bk.setVisible(true);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			});
			btnObrisiKorisnika.setBounds(223, 119, 135, 23);
			contentPanel.add(btnObrisiKorisnika);
		}
		{
			JButton btnDodajRadnika = new JButton("Dodaj radnika");
			btnDodajRadnika.setBackground(new Color(255, 255, 153));
			btnDodajRadnika.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DodavanjeRadnika dr = new DodavanjeRadnika();
					dr.setVisible(true);
				}
			});
			btnDodajRadnika.setBounds(45, 178, 135, 23);
			contentPanel.add(btnDodajRadnika);
		}
		{
			JButton btnObrisiRadnika = new JButton("Obrisi radnika");
			btnObrisiRadnika.setBackground(new Color(255, 255, 153));
			btnObrisiRadnika.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					BrisanjeRadnika br;
					try {
						br = new BrisanjeRadnika();
						br.setVisible(true);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			});
			btnObrisiRadnika.setBounds(223, 178, 135, 23);
			contentPanel.add(btnObrisiRadnika);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(255, 255, 153));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setBackground(new Color(255, 255, 153));
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
