package guiD;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Pocetna {

	private JFrame frmDirektor;
	private JTextField tfIme;
	private JTextField tfLoznika;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pocetna window = new Pocetna();
					window.frmDirektor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pocetna() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmDirektor = new JFrame();
		frmDirektor.getContentPane().setBackground(new Color(0, 204, 204));
		frmDirektor.setTitle("Direktor");
		frmDirektor.setBounds(100, 100, 450, 300);
		frmDirektor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDirektor.getContentPane().setLayout(null);
		
		JLabel lblIme = new JLabel("Ime");
		lblIme.setBounds(32, 41, 46, 14);
		frmDirektor.getContentPane().add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBackground(new Color(255, 204, 102));
		tfIme.setBounds(100, 38, 324, 20);
		frmDirektor.getContentPane().add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblLozinka = new JLabel("Lozinka");
		lblLozinka.setBounds(32, 94, 46, 14);
		frmDirektor.getContentPane().add(lblLozinka);
		
		tfLoznika = new JTextField();
		tfLoznika.setBackground(new Color(255, 204, 102));
		tfLoznika.setBounds(100, 91, 324, 20);
		frmDirektor.getContentPane().add(tfLoznika);
		tfLoznika.setColumns(10);
		
		JButton btnPrijava = new JButton("Prijavi se");
		btnPrijava.setBackground(new Color(255, 255, 153));
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Meni m = new Meni();
				m.setVisible(true);
			}
		});
		btnPrijava.setBounds(163, 185, 91, 34);
		frmDirektor.getContentPane().add(btnPrijava);
	}
}
