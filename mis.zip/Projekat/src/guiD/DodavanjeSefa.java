package guiD;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

import crud.SefCrud;
import java.awt.Color;

public class DodavanjeSefa extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfLozinka;
	SefCrud sc = new SefCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DodavanjeSefa dialog = new DodavanjeSefa();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DodavanjeSefa() {
		setTitle("Dodaj sefa");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 204, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblIme = new JLabel("Ime sefa");
			lblIme.setBounds(36, 44, 74, 14);
			contentPanel.add(lblIme);
		}
		{
			tfIme = new JTextField();
			tfIme.setBackground(new Color(255, 204, 102));
			tfIme.setBounds(120, 41, 304, 20);
			contentPanel.add(tfIme);
			tfIme.setColumns(10);
		}
		{
			JLabel lblPrezime = new JLabel("Prezime sefa");
			lblPrezime.setBounds(36, 91, 74, 14);
			contentPanel.add(lblPrezime);
		}
		{
			tfPrezime = new JTextField();
			tfPrezime.setBackground(new Color(255, 204, 102));
			tfPrezime.setBounds(120, 88, 304, 20);
			contentPanel.add(tfPrezime);
			tfPrezime.setColumns(10);
		}
		{
			JLabel lblLozinka = new JLabel("Lozinka sefa");
			lblLozinka.setBounds(36, 145, 74, 14);
			contentPanel.add(lblLozinka);
		}
		{
			tfLozinka = new JTextField();
			tfLozinka.setBackground(new Color(255, 204, 102));
			tfLozinka.setBounds(120, 142, 304, 20);
			contentPanel.add(tfLozinka);
			tfLozinka.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(255, 255, 153));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Dodaj novog sefa");
				okButton.setBackground(new Color(255, 255, 153));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String ime = tfIme.getText();
						String prezime = tfPrezime.getText();
						String lozinka = tfLozinka.getText();
						try {
							sc.dodajSefa(ime, prezime, lozinka);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(255, 255, 153));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
