package guiD;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.SalterskiRadnikCrud;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class DodavanjeRadnika extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfIme;
	private JTextField tfPrezime;
	private JTextField tfEmail;
	private JTextField tfId;
	private JTextField tfPozicija;
	SalterskiRadnikCrud src = new SalterskiRadnikCrud();
	private JTextField tfLozinka;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DodavanjeRadnika dialog = new DodavanjeRadnika();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DodavanjeRadnika() {
		setTitle("Dodaj radnika");
		setBounds(100, 100, 450, 362);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 204, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblIme = new JLabel("Ime radnika");
			lblIme.setBounds(25, 25, 83, 14);
			contentPanel.add(lblIme);
		}
		{
			tfIme = new JTextField();
			tfIme.setBackground(new Color(255, 204, 102));
			tfIme.setBounds(118, 22, 306, 20);
			contentPanel.add(tfIme);
			tfIme.setColumns(10);
		}
		{
			JLabel lblPrezime = new JLabel("Prezime radnika");
			lblPrezime.setBounds(25, 73, 83, 14);
			contentPanel.add(lblPrezime);
		}
		{
			tfPrezime = new JTextField();
			tfPrezime.setBackground(new Color(255, 204, 102));
			tfPrezime.setBounds(118, 70, 306, 20);
			contentPanel.add(tfPrezime);
			tfPrezime.setColumns(10);
		}
		{
			JLabel lblEmail = new JLabel("Email radnika");
			lblEmail.setBounds(25, 119, 83, 14);
			contentPanel.add(lblEmail);
		}
		{
			tfEmail = new JTextField();
			tfEmail.setBackground(new Color(255, 204, 102));
			tfEmail.setBounds(118, 116, 306, 20);
			contentPanel.add(tfEmail);
			tfEmail.setColumns(10);
		}
		{
			JLabel lblId = new JLabel("ID radnika");
			lblId.setBounds(25, 165, 83, 14);
			contentPanel.add(lblId);
		}
		{
			tfId = new JTextField();
			tfId.setBackground(new Color(255, 204, 102));
			tfId.setBounds(118, 162, 306, 20);
			contentPanel.add(tfId);
			tfId.setColumns(10);
		}
		{
			JLabel lblPozicija = new JLabel("Pozicija radnika");
			lblPozicija.setBounds(25, 203, 83, 14);
			contentPanel.add(lblPozicija);
		}
		{
			tfPozicija = new JTextField();
			tfPozicija.setBackground(new Color(255, 204, 102));
			tfPozicija.setBounds(118, 200, 306, 20);
			contentPanel.add(tfPozicija);
			tfPozicija.setColumns(10);
		}
		{
			JLabel lblLozinka = new JLabel("Lozinka radnika");
			lblLozinka.setBounds(25, 246, 83, 14);
			contentPanel.add(lblLozinka);
		}
		{
			tfLozinka = new JTextField();
			tfLozinka.setBackground(new Color(255, 204, 102));
			tfLozinka.setBounds(118, 243, 306, 20);
			contentPanel.add(tfLozinka);
			tfLozinka.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Unesi novog radnika");
				okButton.setBackground(new Color(255, 255, 153));
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String ime = tfIme.getText();
						String prezime = tfPrezime.getText();
						String email = tfEmail.getText();
						String id = tfId.getText();
						String pozicija = tfPozicija.getText();
						String lozinka = tfLozinka.getText();
						try {
							src.dodaj(ime, prezime, email, id, pozicija, lozinka);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setBackground(new Color(255, 255, 153));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
