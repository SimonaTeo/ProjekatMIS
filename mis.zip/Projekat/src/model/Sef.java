package model;

public class Sef {
	private String ime;
	private String prezime;
	private String loznika;
	public Sef(String ime, String prezime, String loznika) {
		super();
		this.ime = ime;
		this.prezime = prezime;
		this.loznika = loznika;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public String getLoznika() {
		return loznika;
	}
	public void setLoznika(String loznika) {
		this.loznika = loznika;
	}
	@Override
	public String toString() {
		return "Sef [ime=" + ime + ", prezime=" + prezime + "]";
	}
	
}
