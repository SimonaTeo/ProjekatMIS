package model;

public class Posiljka {
	private String tip;
	private int kolicina;
	private String status;
	public Posiljka(String tip, int kolicina, String status) {
		super();
		this.tip = tip;
		this.kolicina = kolicina;
		this.status = status;
	}
	public String getTip() {
		return tip;
	}
	public void setTip(String tip) {
		this.tip = tip;
	}
	public int getKolicina() {
		return kolicina;
	}
	public void setKolicina(int kolicina) {
		this.kolicina = kolicina;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Posiljka [tip=" + tip + ", kolicina=" + kolicina + ", status=" + status + "]";
	}
	
}
