package model;

public class Korisnik {
	
	private String ime;
	private String prezime;
	private String korIme;
	private String lozinka;
	private String brTel;
	private String adresa;
	public Korisnik() {}
	public Korisnik(String ime, String prezime, String korIme, String lozinka, String brTel, String adresa) {
		super();
		this.ime = ime;
		this.prezime = prezime;
		this.korIme = korIme;
		this.lozinka = lozinka;
		this.brTel = brTel;
		this.adresa = adresa;
	}
	
	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public String getKorIme() {
		return korIme;
	}

	public void setKorIme(String korIme) {
		this.korIme = korIme;
	}

	public String getLozinka() {
		return lozinka;
	}

	public void setLozinka(String lozinka) {
		this.lozinka = lozinka;
	}

	public String getBrTel() {
		return brTel;
	}

	public void setBrTel(String brTel) {
		this.brTel = brTel;
	}

	public String getAdresa() {
		return adresa;
	}

	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}

	@Override
	public String toString() {
		return "Korisnik [" + ime + ", " + prezime + ", " + korIme + ", " + brTel + ", " + adresa + "]";
	}
}
