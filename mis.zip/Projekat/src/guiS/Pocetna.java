package guiS;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import crud.SefCrud;
import gui.Prijava;
import guiD.Meni;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Pocetna {

	private JFrame frmSef;
	private JTextField tfIme;
	private JTextField tfLozinka;
	SefCrud sc = new SefCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pocetna window = new Pocetna();
					window.frmSef.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pocetna() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSef = new JFrame();
		frmSef.setTitle("Sef");
		frmSef.getContentPane().setBackground(new Color(0, 204, 204));
		frmSef.setBounds(100, 100, 450, 300);
		frmSef.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSef.getContentPane().setLayout(null);
		
		JLabel lblIme = new JLabel("Ime");
		lblIme.setBounds(34, 51, 46, 14);
		frmSef.getContentPane().add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBackground(new Color(255, 204, 102));
		tfIme.setBounds(109, 48, 315, 20);
		frmSef.getContentPane().add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblLozinka = new JLabel("Lozinka");
		lblLozinka.setBounds(34, 118, 46, 14);
		frmSef.getContentPane().add(lblLozinka);
		
		tfLozinka = new JTextField();
		tfLozinka.setBackground(new Color(255, 204, 102));
		tfLozinka.setBounds(109, 115, 315, 20);
		frmSef.getContentPane().add(tfLozinka);
		tfLozinka.setColumns(10);
		
		JButton btnPrijava = new JButton("Prijavi se");
		btnPrijava.setBackground(new Color(255, 255, 153));
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ime = tfIme.getText();
				String lozinka = tfLozinka.getText();
				try {
					if(sc.prijava(ime, lozinka) == null) {
						JOptionPane.showMessageDialog(null, "Netacni podaci.");
					} else {
						Meni m = new Meni();
						m.setVisible(true);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnPrijava.setBounds(335, 227, 89, 23);
		frmSef.getContentPane().add(btnPrijava);
	}

}
