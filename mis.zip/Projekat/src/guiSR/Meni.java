package guiSR;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import guiD.BrisanjeKorisnika;
import guiD.BrisanjeRadnika;
import guiD.DodavanjeKorisnika;
import guiD.DodavanjeRadnika;
import java.awt.Color;

public class Meni extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Meni dialog = new Meni();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Meni() {
		setTitle("Meni");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 153));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			{
				JButton btnDodajKorisnika = new JButton("Dodaj korisnika");
				btnDodajKorisnika.setBackground(new Color(0, 204, 204));
				btnDodajKorisnika.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						DodavanjeKorisnika dk = new DodavanjeKorisnika();
						dk.setVisible(true);
					}
				});
				btnDodajKorisnika.setBounds(45, 65, 135, 33);
				contentPanel.add(btnDodajKorisnika);
			}
			{
				JButton btnObrisiKorisnika = new JButton("Obrisi korisnika");
				btnObrisiKorisnika.setBackground(new Color(0, 204, 204));
				btnObrisiKorisnika.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						BrisanjeKorisnika bk;
						try {
							bk = new BrisanjeKorisnika();
							bk.setVisible(true);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
				});
				btnObrisiKorisnika.setBounds(223, 65, 135, 33);
				contentPanel.add(btnObrisiKorisnika);
			}
			{
				JPanel buttonPane = new JPanel();
				buttonPane.setBackground(new Color(0, 204, 204));
				buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
				getContentPane().add(buttonPane, BorderLayout.SOUTH);
				{
					JButton cancelButton = new JButton("Cancel");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							setVisible(false);
						}
					});
					cancelButton.setBackground(new Color(0, 204, 204));
					cancelButton.setActionCommand("Cancel");
					buttonPane.add(cancelButton);
				}
			}
		}

	}
}