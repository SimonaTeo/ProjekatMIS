package guiSR;

import java.awt.EventQueue;

import javax.swing.JFrame;

import guiD.Meni;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import crud.SalterskiRadnikCrud;
import java.awt.Color;

public class Pocetna {

	private JFrame frmSalterskiRadnik;
	private JTextField tfIme;
	private JTextField tfLozinka;
	SalterskiRadnikCrud src = new SalterskiRadnikCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pocetna window = new Pocetna();
					window.frmSalterskiRadnik.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Pocetna() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSalterskiRadnik = new JFrame();
		frmSalterskiRadnik.setTitle("Salterski radnik");
		frmSalterskiRadnik.getContentPane().setBackground(new Color(255, 255, 153));
		frmSalterskiRadnik.setBounds(100, 100, 450, 300);
		frmSalterskiRadnik.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSalterskiRadnik.getContentPane().setLayout(null);
		
		JButton btnPrijava = new JButton("Prijavi se");
		btnPrijava.setBackground(new Color(0, 204, 204));
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ime = tfIme.getText();
				String lozinka = tfLozinka.getText();
				try {
					if(src.prijava(ime, lozinka) == null) {
						JOptionPane.showMessageDialog(null, "Netacni podaci.");
					} else {
						Meni m = new Meni();
						m.setVisible(true);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnPrijava.setBounds(156, 194, 89, 23);
		frmSalterskiRadnik.getContentPane().add(btnPrijava);
		
		JLabel lblIme = new JLabel("Ime");
		lblIme.setBounds(38, 49, 46, 14);
		frmSalterskiRadnik.getContentPane().add(lblIme);
		
		tfIme = new JTextField();
		tfIme.setBackground(new Color(0, 204, 204));
		tfIme.setBounds(110, 46, 314, 20);
		frmSalterskiRadnik.getContentPane().add(tfIme);
		tfIme.setColumns(10);
		
		JLabel lblLozinka = new JLabel("Lozinka");
		lblLozinka.setBounds(38, 114, 46, 14);
		frmSalterskiRadnik.getContentPane().add(lblLozinka);
		
		tfLozinka = new JTextField();
		tfLozinka.setBackground(new Color(0, 204, 204));
		tfLozinka.setBounds(110, 111, 314, 20);
		frmSalterskiRadnik.getContentPane().add(tfLozinka);
		tfLozinka.setColumns(10);
	}

}
